
<main>
      <div
        class="relative pt-16 pb-32 flex content-center items-center justify-center"
        style="min-height: 75vh;"
      >
        <div
          class="absolute top-0 w-full h-full bg-center bg-cover"
          style='background-image: url("assets/img/background desa.jpg");'
        >
          <span
            id="blackOverlay"
            class="w-full h-full absolute opacity-75 bg-gray-900"
          ></span>
        </div>
        <div class="container relative mx-auto">
          <div class="items-center flex flex-wrap">
            <div class="w-full lg:w-6/12 px-4 ml-auto mr-auto text-center">
              <div class="pr-12">
                <h1 class="text-white font-semibold text-5xl">
                  Layanan Pengaduan Masyarakat
                </h1>
                <p class="mt-4 text-lg text-gray-300">
                Tingkatkan Keterlibatan, Sambut Suara Masyarakat: Platform Pengaduan yang Melayani Kebutuhan Anda dari Desa Laut Tador, Kecamatan Laut Tador, Kabupaten Batu Bara
                </p>
              </div>
            </div>
          </div>
        </div>
        <div
          class="top-auto bottom-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden"
          style="height: 70px;"
        >
          <svg
            class="absolute bottom-0 overflow-hidden"
            xmlns="http://www.w3.org/2000/svg"
            preserveAspectRatio="none"
            version="1.1"
            viewBox="0 0 2560 100"
            x="0"
            y="0"
          >
            <polygon
              class="text-gray-300 fill-current"
              points="2560 0 2560 100 0 100"
            ></polygon>
          </svg>
        </div>
      </div>
      <section class="pb-20 bg-gray-300 -mt-24">
        <div class="container mx-auto px-4">
          <div class="flex flex-wrap">
            <div class="lg:pt-12 pt-6 w-full md:w-4/12 px-4 text-center">
              <div
                class="relative flex flex-col min-w-0 break-words bg-gray-100 w-full mb-8 shadow-lg rounded-lg"
              >
                <div class="px-4 py-5 flex-auto">
                  <div
                    class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 mb-5 shadow-lg rounded-full bg-red-400"
                  >
                    <i class="fas fa-award"></i>
                  </div>
                  <h6 class="text-xl font-semibold">Tulis Laporan</h6>
                  <p class="mt-2 mb-4 text-gray-600">
                    Tulis laporan keluhan Anda dengan jelas.
                  </p>
                </div>
              </div>
            </div>
            <div class="w-full md:w-4/12 px-4 text-center">
              <div
                class="relative flex flex-col min-w-0 break-words bg-gray-200 w-full mb-8 shadow-lg rounded-lg"
              >
                <div class="px-4 py-5 flex-auto">
                  <div
                    class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 mb-5 shadow-lg rounded-full bg-blue-400"
                  >
                    <i class="fas fa-retweet"></i>
                  </div>
                  <h6 class="text-xl font-semibold">Proses Verifikasi</h6>
                  <p class="mt-2 mb-4 text-gray-600">
                  Tunggu sampai laporan Anda di verifikasi.
                  </p>
                </div>
              </div>
            </div>
            <div class="pt-6 w-full md:w-4/12 px-4 text-center">
              <div
                class="relative flex flex-col min-w-0 break-words bg-gray-200 w-full mb-8 shadow-lg rounded-lg"
              >
                <div class="px-4 py-5 flex-auto">
                  <div
                    class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 mb-5 shadow-lg rounded-full bg-green-400"
                  >
                    <i class="fas fa-fingerprint"></i>
                  </div>
                  <h6 class="text-xl font-semibold">Tindak Lanjut</h6>
                  <p class="mt-2 mb-4 text-gray-600">
                  Laporan Anda sedang dalam tindak lanjut.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="flex flex-wrap items-center mt-32">
            <div class="w-full md:w-5/12 px-4 mr-auto ml-auto">
              <div
                class="text-gray-600 p-3 text-center inline-flex items-center justify-center w-16 h-16 mb-6 shadow-lg rounded-full bg-gray-100"
              >
                <i class="fas fa-users text-xl"></i>
              </div>
              <h3 class="text-3xl mb-2 font-semibold leading-normal">
                Pengaduan Masyarakat
              </h3>
              <p
                class="text-lg font-light leading-relaxed mt-4 mb-4 text-gray-700"
              >
              laporan dari masyarakat mengenai adanya indikasi terjadinya penyimpangan, korupsi, kolusi dan nepotisme yang dilakukan aparat pemerintah daerah dalam penyelenggaraan pemerintahan.
              </p>
              <p
                class="text-lg font-light leading-relaxed mt-0 mb-4 text-gray-700"
              >
              Pengaduan masyarakat dalam pelayanan publik umum terjadi ketika masyarakat selaku pengguna layanan tidak puas atas pelayanan yang diberikan, bahkan menambah kekecewaan ketika pengaduan yang disampaikan tidak dikelola atau ditanggapi secara baik oleh petugas pengaduan.
              </p>
            </div>
            <div class="w-full md:w-4/12 px-4 mr-auto ml-auto">
              <div
                class="relative flex flex-col min-w-0 break-words  w-full mb-6 shadow-lg rounded-lg bg-gray-100"
              >
                <img
                  alt="..."
                  src="<?php echo e(asset('assets/img/background desa.jpg')); ?>"
                  class="w-full align-middle rounded-t-lg"
                />
                <blockquote class="relative p-8 mb-4">
                  <svg
                    preserveAspectRatio="none"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 583 95"
                    class="absolute left-0 w-full block"
                    style="height: 95px; top: -94px;"
                  >
                    <polygon
                      points="-30,95 583,95 583,65"
                      class="text-gray-100 fill-current"
                    ></polygon>
                  </svg>
                  <h4 class="text-xl font-bold text-black">
                    Desan Laut Tador
                  </h4>
                  <p class="text-md font-light mt-2 text-black">
                    Kecamatan Laut Tador, Kabupaten Batu Bara
                  </p>
                </blockquote>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="relative py-20">
        <div
          class="bottom-auto top-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden -mt-20"
          style="height: 80px;"
        >
          <svg
            class="absolute bottom-0 overflow-hidden"
            xmlns="http://www.w3.org/2000/svg"
            preserveAspectRatio="none"
            version="1.1"
            viewBox="0 0 2560 100"
            x="0"
            y="0"
          >
            <polygon
              class="text-white fill-current"
              points="2560 0 2560 100 0 100"
            ></polygon>
          </svg>
        </div>
        <div class="container mx-auto px-4">
          <div class="items-center flex flex-wrap">
            <div class="w-full md:w-4/12 ml-auto mr-auto px-4">
              <img
                alt="..."
                class="max-w-full rounded-lg shadow-lg"
                src="<?php echo e(asset('assets/img/aduan.png')); ?>"
              />
            </div>
            <div class="w-full  md:w-5/12 ml-auto mr-auto px-4">
              <div class="md:pr-12">
                <div
                  class="text-pink-600 p-3 text-center inline-flex items-center justify-center w-16 h-16 mb-6 shadow-lg rounded-full bg-gray-300"
                >
                  <i class="fas fa-rocket text-xl"></i>
                </div>
                <h3 class="text-3xl font-semibold">Ruang Lingkup Pengaduan</h3>
                <p class="mt-4 text-lg leading-relaxed text-gray-600">
                Ruang lingkup penanganan pengaduan masyarakat meliputi tindakan testocyp online atau dugaan maladministrasi oleh pejabat publik di lingkungan Pemerintah Desa laut tador Kabupaten Batubara yang dapat diadukan, yaitu antara lain:
                </p>
                <ul class="list-none mt-6">
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Penundaan berlarut;
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Penyalahgunaan wewenang;
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Bertindak sewenang-wenang, tidak adil dan tidak patut;
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Penyimpangan prosedur;
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Perbuatan melawan hukum;
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Korupsi, kolusi dan nepotisme;
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3"
                          ><i class="fas fa-point"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-600">
                        Lain-lain tindakan pejabat publik yang merugikan masyarakat.
                        </h4>
                      </div>
                    </div>
                  </li>
                  
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="pt-20 pb-48">
        <div class="container mx-auto px-4">
          <div class="flex flex-wrap justify-center text-center mb-24">
            <div class="w-full lg:w-6/12 px-4">
              <h2 class="text-4xl font-semibold">Artikel</h2>
              <p class="text-lg leading-relaxed m-4 text-gray-600">
                Informasi terbaru mengenai pelaksanaan beberapa pengaduan dari masyarakat dan Informasi dari kabar sepekan dari desa laut tador ataupun dari kabar dari lingkup kabupaten batubara.
              </p>
            </div>
          </div>
          <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
              <a href="#">
                  <img class="rounded-t-lg" src="<?php echo e(asset('storage/images/' . $article->image)); ?>" alt="<?php echo e($article->judul); ?>" />
              </a>
              <div class="p-5">
                  <a href="#">
                      <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white"><?php echo e($article->judul); ?></h5>
                  </a>
                  <p class="mb-3 font-normal text-gray-700 dark:text-gray-400"><?php echo e($article->description); ?></p>
                  <a href="#" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                      Read more
                      <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
                      </svg>
                  </a>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </section>
      <section class="pb-20 relative block bg-gray-900" style="background-image: url('assets/img/background desa.jpg'); background-size: cover; background-position: center; position: relative;">
      <div class="absolute inset-0 bg-black opacity-75"></div>
        <div class="bottom-auto top-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden -mt-20" style="height: 80px;">
            <svg class="absolute bottom-0 overflow-hidden" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" version="1.1" viewBox="0 0 2560 100" x="0" y="0">
                <polygon class="text-gray-900 fill-current" points="2560 0 2560 100 0 100"></polygon>
            </svg>
        </div>
    <div class="container mx-auto px-4 lg:pt-24 lg:pb-64 relative z-10 flex flex-wrap items-center">
    <div class="w-full lg:w-6/12 px-4">
        <h2 class="text-4xl font-semibold text-white">Senang Melayani Anda</h2>
        <p class="text-lg leading-relaxed mt-4 mb-4 text-gray-300">
            Kami turut serta dalam pemerintahan di Desa Laut Tador, Kecamatan Laut Tador, Kabupaten Batubara, dan sangat senang dengan laporan masyarakat yang membantu kami menyadari kekurangan dalam pelayanan kami.
        </p>
        <ul class="list-none mt-6">
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-white mr-3"
                          ><i class="fas fa-phone"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-200">
                        +628-576108-8663
                        </h4>
                      </div>
                    </div>
                  </li>
                  <li class="py-2">
                    <div class="flex items-center">
                      <div>
                        <span
                          class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-white mr-3"
                          ><i class="fas fa-envelope"></i
                        ></span>
                      </div>
                      <div>
                        <h4 class="text-gray-200">
                        Desalauttador@gmail.com
                        </h4>
                      </div>
                    </div>
                  </li>
          </ul>
    </div><br>
    <div class="w-full lg:w-6/12 px-4">
        <!-- Tambahkan iframe untuk Google Maps di sini -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.646671579934!2d106.83124381537293!3d-6.214235195489498!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6a45c3b8a3db93%3A0xd1fcd0e3a16a9874!2sKabupaten%20Batubara%2C%20Sumatra%20Utara!5e0!3m2!1sen!2sid!4v1644383146553!5m2!1sen!2sid" width="550" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
  </div>

</section>



    </main>



    

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\pengkat\resources\views/frontend/landing.blade.php ENDPATH**/ ?>